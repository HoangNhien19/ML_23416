import pandas as pd

df=pd.read_csv("../datasets/SalesTransactions/SalesTransactions.txt",
               sep='\t')

print(df)